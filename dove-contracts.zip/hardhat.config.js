require("@nomiclabs/hardhat-waffle");
module.exports = {
  solidity: "0.7.5",
};
